
## Requirements

- PHP 7.0 or higher
- LibreOffice installed on your system

## Installation

1. Ensure PHP is installed and available in your system's PATH.
2. Install LibreOffice and note its installation path.

To add LibreOffice to your PATH on Windows:

Find LibreOffice Installation Path
Usually, it's something like:
C:\Program Files\LibreOffice\program
Add to System PATH

Verify in Command Prompt
soffice --version

If installed and added correctly, it will show the LibreOffice version.


