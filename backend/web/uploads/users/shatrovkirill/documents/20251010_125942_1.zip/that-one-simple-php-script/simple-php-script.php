<?php
$contractsDir = 'contracts';
$baseFormDir = 'base_form';

// Get all XML files in contracts
$xmlFiles = glob($contractsDir . '/*.xml');

// Find matching DOCX/XML pairs
$pairs = [];
foreach ($xmlFiles as $xmlFile) {
    $baseName = pathinfo($xmlFile, PATHINFO_FILENAME);
    $docxTemplate = $baseFormDir . '/' . $baseName . '.docx';
    if (file_exists($docxTemplate)) {
        $pairs[] = [
            'xml' => $xmlFile,
            'docx' => $docxTemplate
        ];
    }
}

// Use the first matching pair (or handle as needed)
if (!empty($pairs)) {
    $xmlFile = $pairs[0]['xml'];
    $docxTemplate = $pairs[0]['docx'];
} else {
    die('No matching XML/DOCX pairs found.');
}

// Get the base name without extension
$baseName = pathinfo($docxTemplate, PATHINFO_FILENAME);

$outputDocx = "output/{$baseName}.docx";
$outputPdf = "output/{$baseName}.pdf";

$xml = simplexml_load_file($xmlFile);
$vars = [];
foreach ($xml as $key => $value) {
    $vars['{{' . $key . '}}'] = (string)$value;
}

// Unzip DOCX
$zip = new ZipArchive;
if ($zip->open($docxTemplate) === TRUE) {
    $tempDir = sys_get_temp_dir() . '/docx_' . uniqid();
    mkdir($tempDir);

    $zip->extractTo($tempDir);
    $zip->close();

    // Replace in document.xml
    $documentXml = file_get_contents($tempDir . '/word/document.xml');
    foreach ($vars as $key => $value) {
        $documentXml = str_replace($key, $value, $documentXml);
    }
    file_put_contents($tempDir . '/word/document.xml', $documentXml);

    // Zip back to a new docx
    $zip2 = new ZipArchive;
    $zip2->open($outputDocx, ZipArchive::CREATE | ZipArchive::OVERWRITE);
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($tempDir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($files as $file) {
        $filePath = $file->getRealPath();
        $relativePath = substr($filePath, strlen($tempDir) + 1);
        $relativePath = str_replace('\\', '/', $relativePath); // <-- Add this line
        if ($file->isDir()) {
            $zip2->addEmptyDir($relativePath);
        } else {
            $zip2->addFile($filePath, $relativePath);
        }
    }
    $zip2->close();
}

// Convert DOCX to PDF
// Option 1: Command line (if you have LibreOffice installed)
exec('soffice --headless --convert-to pdf "'.$outputDocx.'" --outdir output');
echo "donezo";
?>
