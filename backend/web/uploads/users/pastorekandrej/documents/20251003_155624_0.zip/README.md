# 🧩 Pexeso — Memory Game

Simple web application in PHP + JavaScript.
Game "pexeso" (memory game) with a list of 18 tools, with support for **EN / SK / HU** languages ​​and voice reading using **Web Speech API**.

---

## 🚀 How to start a project

1. Make sure you have **PHP (>=8.0)** installed.
   Check version:

   ```bash
   php -v
   ```

2. Start the built-in PHP server in the project folder:

   ```bash
   php -S localhost:8000
   ```

3. Open the game in your browser:

   ```
   http://localhost:8000
   ```

4. Choose your language (EN / SK / HU) in the top bar.

        * Texts and voice reading will be adapted to the selected language.
        * When "Sound" is turned on, the name of the tool will be read after turning the card.

---

## 🛠️ List of 18 tools

The cards used are the following paired tools:

1. Screw
2. Saw
3. Level
4. Cutter
5. File
6. Wrench
7. Hammer
8. Bolt
9. Grinder
10. Paintbrush
11. Rivet
12. Sander
13. Tape
14. Drill
15. Pliers
16. Clamp
17. Chisel
18. Router

---

## 📂 Project structure

```
pexeso-tools/
├── index.php
├── ajax.php
├── inc/
│   ├── init.php
│   ├── game.php
│   └── i18n.php
├── templates/
│   ├── header.php
│   ├── footer.php
│   └── tile.php
├── assets/
│   ├── css/style.css
│   └── js/game.js
└── README.md   ← this file
```

---

## ✨ Functions

* Modern design with animated card rotation
* Audio reading of the tool name (Web Speech API)
* Multilingual support (EN, SK, HU)
* Counting of moves and found pairs
* Highlight effect of found pairs (purple)

---
