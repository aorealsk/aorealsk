// assets/js/game.js
// client-side behavior (AJAX + progressive enhancement)
(function() {
    const board = document.getElementById('board');
    const newGameBtn = document.getElementById('newGameBtn');
    const movesCount = document.getElementById('movesCount');
    const matchesCount = document.getElementById('matchesCount');
    const soundToggle = document.getElementById('soundToggle');

    // helper: post JSON to server
    async function postAjax(url, data) {
        const resp = await fetch(url, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        });
        return resp.json();
    }

    // --- TTS voice management ---
    let voices = [];
    function loadVoices() {
        voices = window.speechSynthesis.getVoices() || [];
    }
    if (window.speechSynthesis) {
        loadVoices();
        window.speechSynthesis.onvoiceschanged = loadVoices;
    }

    function getLocaleForLang(lang) {
        switch(lang) {
            case 'sk': return 'sk';
            case 'hu': return 'hu';
            default: return 'en';
        }
    }

    // choose best available voice for language (returns Voice object or null)
    function pickVoiceForLang(lang) {
        const voices = speechSynthesis.getVoices();
        if (!voices.length) return null;

        const preferred = {
            'sk': ['Google UK Slovak Female','Microsoft Filip - Slovak (Natural)'],
            'hu': ['Google magyar','Microsoft András - Hungarian (Natural)'],
            'en': ['Google US English','Microsoft Zira Desktop']
        };

        if (preferred[lang]) {
            for (const name of preferred[lang]) {
                const v = voices.find(vo => vo.name.includes(name));
                if (v) return v;
            }
        }

        // fallback podľa lang kódu
        const localePrefix = lang;
        let candidates = voices.filter(v => v.lang && v.lang.toLowerCase().startsWith(localePrefix));
        if (candidates.length) return candidates[0];

        return voices[0]; // úplný fallback
    }

    function speakText(text, lang) {
        if (!window.speechSynthesis) return;
        try {
            const utter = new SpeechSynthesisUtterance(text);
            // set lang and pick a voice if available
            utter.lang = (lang === 'sk' ? 'sk-SK' : (lang === 'hu' ? 'hu-HU' : 'en-US'));
            const voice = pickVoiceForLang(lang);
            if (voice) utter.voice = voice;
            // optional tuning:
            utter.rate = 1.0;
            utter.pitch = 1.0;
            window.speechSynthesis.speak(utter);
        } catch (e) {
            console.warn('TTS error', e);
        }
    }

    // restore sound preference
    try {
        const pref = localStorage.getItem('pexeso_sound');
        if (pref !== null) soundToggle.checked = pref === '1';
    } catch(e){}

    // toggle sound preference
    soundToggle.addEventListener('change', function() {
        try {
            localStorage.setItem('pexeso_sound', this.checked ? '1' : '0');
        } catch(e){}
    });

    // click on tile
    board.addEventListener('click', async function(e) {
        const btn = e.target.closest('.tile');
        if (!btn) return;
        if (btn.classList.contains('flipped') || btn.classList.contains('matched')) return;
        const id = btn.getAttribute('data-id');

        // optimistically flip UI
        btn.classList.add('flipped');

        /** @type {{ok:boolean, moves?:number, matches?:number, revealed?:number[], match?:boolean, game_over?:boolean, item?:string, item_id?:number}} */
        const resp = await postAjax('/ajax.php', {action: 'flip', id: id});
        if (!resp.ok) {
            console.error(resp);
            return;
        }

        // update scoreboard
        if (resp.moves !== undefined) movesCount.textContent = resp.moves.toString();
        if (resp.matches !== undefined) matchesCount.textContent = resp.matches.toString() + '/18';

        // speak item if enabled (resp.item is localized by ajax.php)
        if (soundToggle.checked && window.speechSynthesis) {
            const textToSpeak = resp.item || (btn.querySelector('.tile-face.back') ? btn.querySelector('.tile-face.back').textContent : '');
            speakText(textToSpeak, window.PEX && window.PEX.lang ? window.PEX.lang : 'en');
        }

        // === Handle mismatch ===
        if (resp.match === false && resp.revealed && resp.revealed.length === 2) {
            setTimeout(() => {
                resp.revealed.forEach(i => {
                    const el = document.querySelector('.tile[data-id="'+i+'"]');
                    if (el && !el.classList.contains('matched')) el.classList.remove('flipped');
                });
                // optional: tell server to clear revealed states
                postAjax('/ajax.php', {action:'hide', ids: resp.revealed});
            }, 600);
        }

        // === Handle match immediately ===
        if (resp.match === true && resp.revealed && resp.revealed.length === 2) {
            resp.revealed.forEach(i => {
                const el = document.querySelector('.tile[data-id="'+i+'"]');
                if (el) {
                    el.classList.add('matched');
                }
            });
        }

        // === Game Over ===
        if (resp.match === true && resp.game_over) {
            setTimeout(() => {
                // localized win message (from server i18n passed as window.PEX.texts.win_message)
                const winTpl = (window.PEX && window.PEX.texts && window.PEX.texts.win_message) ? window.PEX.texts.win_message : 'You won in {moves} moves!';
                const msg = winTpl.replace('{moves}', resp.moves || '');
                alert(msg);
                if (soundToggle.checked && window.speechSynthesis) {
                    speakText(msg, window.PEX && window.PEX.lang ? window.PEX.lang : 'en');
                }
            }, 300);
        }
    });

    // New Game button
    newGameBtn.addEventListener('click', async function() {
        await postAjax('/ajax.php', {action:'new'});
        location.reload(); // reload to reset board
    });
})();
