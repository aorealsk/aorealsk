<footer>
    <p style="text-align:center;padding:1rem 0;font-size:.9rem;opacity:.7">Pexeso — small PHP project</p>
</footer>
</body>
</html>