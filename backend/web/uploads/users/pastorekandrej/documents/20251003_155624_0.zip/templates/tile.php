<?php
// expects $idx, $item, $revealed, $matched
$isRevealed = in_array($idx, $revealed);
$isMatched = $matched[$idx] ?? false;

// for accessibility label
$label = htmlspecialchars($item);
?>

<div class="tile <?= $isRevealed || $isMatched ? 'flipped' : '' ?> <?= $isMatched ? 'matched' : '' ?>" data-id="<?= $idx ?>">
    <div class="tile-inner">
        <div class="tile-face front">?</div>
        <div class="tile-face back"><?= htmlspecialchars($item) ?></div>
    </div>
</div>
