<?php
require_once __DIR__ . '/inc/init.php';
require_once __DIR__ . '/inc/game.php';
require_once __DIR__ . '/inc/i18n.php';


// handle language selection
$lang = $_SESSION['lang'] ?? 'en';
if (!in_array($lang, ['en','sk','hu'])) $lang = 'en';
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en','sk','hu'])) {
    $_SESSION['lang'] = $_GET['lang'];
    $lang = $_GET['lang'];
}


$txt = get_texts($lang);


// Ensure game is initialized
if (!game_is_initialized()) {
    game_new();
}


$board = $_SESSION['board'];
$revealed = $_SESSION['revealed'];
$matched = $_SESSION['matched'];
$moves = $_SESSION['moves'];
$matches = $_SESSION['matches'];


include __DIR__ . '/templates/header.php';
?>


    <main class="wrap">
        <header class="topbar">
            <h1><?=htmlspecialchars($txt['title'])?></h1>
            <div class="controls">
                <form id="langForm" method="get" action="/">
                    <label for="langSelect"><?=htmlspecialchars($txt['language'])?>:</label>
                    <select id="langSelect" name="lang" onchange="document.getElementById('langForm').submit();">
                        <option value="en" <?= $lang==='en' ? 'selected' : '' ?>>EN</option>
                        <option value="sk" <?= $lang==='sk' ? 'selected' : '' ?>>SK</option>
                        <option value="hu" <?= $lang==='hu' ? 'selected' : '' ?>>HU</option>
                    </select>
                </form>


                <label class="sound-toggle">
                    <input id="soundToggle" type="checkbox">
                    <?=htmlspecialchars($txt['sound'])?>
                </label>


                <button id="newGameBtn" class="btn"><?=htmlspecialchars($txt['new_game'])?></button>
            </div>
        </header>


        <section class="scoreboard">
            <div><?=htmlspecialchars($txt['moves'])?>: <span id="movesCount"><?= $moves ?></span></div>
            <div><?=htmlspecialchars($txt['matches'])?>: <span id="matchesCount"><?= $matches ?>/18</span></div>
        </section>


        <section id="board" class="board">
            <?php foreach ($board as $idx => $toolName):
                // toolName môže byť originálny (anglický) názov, zistíme jeho index v globálnom poli TOOLS
                $toolIndex = array_search($toolName, $GLOBALS['TOOLS'] ?? [], true);
                // ak nájdeme index, použijeme lokalizovaný štítok z $txt['tools']; inak použijeme pôvodný text
                $item = ($toolIndex !== false && isset($txt['tools'][$toolIndex])) ? $txt['tools'][$toolIndex] : $toolName;
                include __DIR__ . '/templates/tile.php';
            endforeach; ?>
        </section>


    </main>


    <script>
        // pass i18n labels to JS
        window.PEX = {};
        window.PEX.lang = <?= json_encode($lang) ?>;
        window.PEX.texts = <?= json_encode($txt) ?>;
    </script>
    <script src="/assets/js/game.js"></script>
    <link rel="stylesheet" href="/assets/css/style.css">


<?php include __DIR__ . '/templates/footer.php'; ?>