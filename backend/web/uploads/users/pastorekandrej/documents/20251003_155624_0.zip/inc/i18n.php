<?php
function get_texts($lang = 'en') {
    $dict = [
        'en' => [
            'title' => 'Pexeso — Memory Game',
            'new_game' => 'New Game',
            'moves' => 'Moves',
            'matches' => 'Matches',
            'sound' => 'Sound',
            'language' => 'Language',
            'win_message' => 'You won in {moves} moves!',
            // 18 tools - keep same order for all languages
            'tools' => [
                'Drill','Screw','Saw','Wrench','Hammer','Bolt','Grinder','Paintbrush','Rivet',
                'Sander','Level','Cutter','File','Tape','Pliers','Clamp','Chisel','Router'
            ],
        ],
        'sk' => [
            'title' => 'Pexeso — Pamäťová hra',
            'new_game' => 'Nová hra',
            'moves' => 'Ťahy',
            'matches' => 'Zhody',
            'sound' => 'Zvuk',
            'language' => 'Jazyk',
            'win_message' => 'Vyhral si za {moves} ťahov!',
            'tools' => [
                'Vŕtačka','Skrutka','Píla','Kľúč','Kladivo','Šrób','Brúska','Štetec','Nit',
                'Brúska (sander)','Vodováha','Strihák','Pilník','Páska','Kliešte','Svorka','Dlátko','Fréza'
            ],
        ],
        'hu' => [
            'title' => 'Pexeso — Memória játék',
            'new_game' => 'Új játék',
            'moves' => 'Lépések',
            'matches' => 'Párok',
            'sound' => 'Hang',
            'language' => 'Nyelv',
            'win_message' => 'Nyertél {moves} lépéssel!',
            'tools' => [
                'Fúró','Csavar','Fűrész','Csavarkulcs','Kalapács','Csavar','Csiszoló','Ecset','Szegecs',
                'Csiszoló (sander)','Vízszintező','Vágó','Reszelő','Ragasztószalag','Fogó','Bilincs','Véső','Maró'
            ],
        ],
    ];

    return $dict[$lang] ?? $dict['en'];
}
