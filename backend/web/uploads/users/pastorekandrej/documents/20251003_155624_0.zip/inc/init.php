<?php
session_start();


// basic config
define('BOARD_SIZE', 36);
define('PAIRS', 18);


auto_flush();


function auto_flush() {
// nothing for now; placeholder
}


// load tools list
$toolsFile = __DIR__ . '/../data/tools.json';
if (file_exists($toolsFile)) {
    $TOOLS = json_decode(file_get_contents($toolsFile), true);
} else {
// fallback basic list
    $TOOLS = [
        'drill','screw','saw','hammer','wrench','pliers','chisel','tape','level','sander','rivet','bolt','cutter','file','router','clamp','grinder','paintbrush'
    ];
}


// expose to other include files
$GLOBALS['TOOLS'] = $TOOLS;