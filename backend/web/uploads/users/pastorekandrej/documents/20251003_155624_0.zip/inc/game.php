<?php
require_once __DIR__ . '/init.php';

function game_is_initialized() {
    return isset($_SESSION['board']) && is_array($_SESSION['board']);
}

function game_new() {
    $tools = $GLOBALS['TOOLS'];
    // create pairs
    $pairs = array_slice($tools, 0, PAIRS);
    $deck = [];
    foreach ($pairs as $t) {
        $deck[] = $t;
        $deck[] = $t;
    }
    // shuffle
    shuffle($deck);

    $_SESSION['board'] = $deck;
    $_SESSION['revealed'] = [];
    $_SESSION['matched'] = array_fill(0, BOARD_SIZE, false);
    $_SESSION['moves'] = 0;
    $_SESSION['matches'] = 0;

    return true;
}


function game_flip(int $idx) {
    $board = &$_SESSION['board'];
    $revealed = &$_SESSION['revealed'];
    $matched = &$_SESSION['matched'];


    $boardSize = count($board);
    if ($idx < 0 || $idx >= $boardSize) return ['ok'=>false, 'error'=>'out_of_bounds'];


    if ($matched[$idx]) {
        return ['ok'=>false, 'error'=>'already_matched'];
    }


    if (in_array($idx, $revealed)) {
        return ['ok'=>false, 'error'=>'already_revealed'];
    }


// add to revealed
    $revealed[] = $idx;


    $response = [
        'ok' => true,
        'id' => $idx,
        'item' => $board[$idx],
        'revealed' => $revealed,
        'moves' => $_SESSION['moves'],
        'matches' => $_SESSION['matches'],
    ];


    if (count($revealed) === 2) {
        $_SESSION['moves'] += 1;
        $a = $revealed[0];
        $b = $revealed[1];
        if ($board[$a] === $board[$b]) {
// match
            $matched[$a] = true;
            $matched[$b] = true;
            $_SESSION['matches'] += 1;
// clear revealed
            $_SESSION['revealed'] = [];
            $response['match'] = true;
            $response['matches'] = $_SESSION['matches'];
            $response['moves'] = $_SESSION['moves'];
            $response['game_over'] = ($_SESSION['matches'] >= PAIRS);
        } else {
// mismatch: keep revealed in response; frontend will handle timeout and then call hide
            $response['match'] = false;
// do NOT clear revealed yet; wait for frontend to request hide or perform auto-hide
        }
    }


    return $response;
}


function game_hide(array $ids) {
// helper if you want server to clear revealed after mismatch
    foreach ($ids as $i) {
        if (($k = array_search($i, $_SESSION['revealed'])) !== false) {
            unset($_SESSION['revealed'][$k]);
        }
    }
// normalize
    $_SESSION['revealed'] = array_values($_SESSION['revealed']);
    return ['ok'=>true, 'revealed'=>$_SESSION['revealed']];
}