<?php
session_start();
require_once __DIR__ . '/inc/init.php';
require_once __DIR__ . '/inc/game.php';
require_once __DIR__ . '/inc/i18n.php';

header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['ok'=>false, 'error'=>'no_input']);
    exit;
}

$lang = $_SESSION['lang'] ?? 'en';
$texts = get_texts($lang);

$action = $input['action'] ?? '';
switch ($action) {
    case 'new':
        game_new();
        echo json_encode(['ok'=>true]);
        break;

    case 'flip':
        $id = intval($input['id'] ?? -1);
        $resp = game_flip($id);

        // if server returned an 'item' (string), try to map it to localized tools[]
        if (!empty($resp['ok']) && isset($resp['item'])) {
            $globalTools = $GLOBALS['TOOLS'] ?? [];
            $idx = array_search($resp['item'], $globalTools, true);
            if ($idx !== false && isset($texts['tools'][$idx])) {
                $resp['item'] = $texts['tools'][$idx];   // localized label
                $resp['item_id'] = $idx;                 // useful for client-side
            }
        }

        echo json_encode($resp);
        break;

    case 'hide':
        $ids = $input['ids'] ?? [];
        echo json_encode(game_hide($ids));
        break;

    default:
        echo json_encode(['ok'=>false, 'error'=>'unknown_action']);
}
